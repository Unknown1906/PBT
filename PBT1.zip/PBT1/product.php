<!DOCTYPE html>
<html>
<head>
	<title>PSP PC-Shop</title>
    <style>
	
		/* CSS styles for header */
        h1 {
            background-color: purple;
            width: 100%;
            height: 45px;
            color: white;
            text-align: center;
            margin: 0;
            padding: 20px 0 20px 0;
        }

        /* CSS styles for buttons */
        button {
            width: 10%;
            height: 30px;
            background-color: purple;
            color: white;
        }

        button:hover {
            background-color: #2A38F5;
            color: purple;
        }

        /* CSS styles for images */
        img {
            width: 270px;
            height: 200px;
        }

        /* CSS styles for tables */
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
            margin-top: 0;
        }

        td, th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        /* CSS styles for empty space */
        #empty {
            height: 20px;
        }

        /* CSS styles for alternating row colors */
        .color tr:nth-child(odd) {
            background-color: #E8E8E8;
        }

        /* CSS styles for required fields */
        .requirement {
            color: red;
            font-weight: bold;
            margin-right: 5px;
        }

        /* CSS styles for input elements */
        .row {
            width: 38%;
        }

        .main {
            width: 30%;
        }

        #text {
            height: 70px;
            width: 30%;
        }

        #id {
            width: 12%;
        }

        #product {
            background-color: purple;
            color: white;
        }

        .product {
            width: 35%;
        }

        .image {
            width: 34%;
            height: 50%;
            text-align: center;
        }

        .price {
            text-align: center;
        }

        input[type="number"] {
            margin: 0 6px 0 6px;
            width: 90%;
        }

        .payment {
            margin-top: 10px;
            background-color: #E8E8E8;
            padding: 1px 0 1px 0;
        }

        p {
            font-family: arial;
            font-weight: bold;
        }

        #sst {
            color: blue;
        }

        #method {
            margin-left: 5px;
        }

        .button {
            text-align: center;
        }

        .btn {
            height: 35px;
        }
			
    </style>
</head>
<body>
	<!-- Header -->
    <h1>Welcome to PSP PC-Shop</h1>
	
	<!-- Form -->
    <form action="process.php" method="POST">
		<!-- Personal Information Table -->
		<table class = "color" align="center" border="2">
			<!-- Input Field for Name -->
			<tr>
				<td class = "row"><b><span class="requirement">*</span>Full Name:</b></td>
				<td><input type="text" name="name" class ="main" required pattern="[a-zA-Z\s]+" title="Please enter only letters and whitespace" 
				placeholder = "Full Name"/></td>
			</tr>
			<!-- Input Field for Email -->
			<tr>
				<td><span class="requirement">*</span><b>Email:</b></td>
				<td><input type="email" class ="main" name="email" required placeholder = "Email" /></td>
			</tr>
			<!-- Input Field for Phone Number -->
			<tr>
				<td><span class="requirement">*</span><b>Phone Number:</b></td>
				<td><input type="text" class ="main" name="phone" required pattern="\d{3}-\d{7}" 
				title="Please enter a phone number in the format 012-3456789" placeholder = "example: 012-3456789"/></td>
			</tr>
			<!-- Input Field for Address -->
			<tr>
				<td><span class="requirement">*</span><b>Address:</b></td>
				<td><textarea id = "text" name="address" required placeholder = "Address"></textarea></td>
			</tr>
			<!-- Input Field for Date -->
			<tr>
				<td><span class="requirement">*</span><b>Date:</b></td>
				<td><input type="date" id = "date" name="date" required min="2023-12-01" max="2030-12-31"/></td>
			</tr>
			<!-- For empty row -->
			<tr>
				<td colspan = 2 id="empty" ></td>
			</tr>
		</table>

		<!-- Product Selection Table -->
		<table class="color" align="center" border="2">
			<!-- Table headers for product details -->
			<tr id = "product">
				<th colspan="2" ></th>
				<th><center><b>Product</b></center></th>
				<th><center><b>Price</b></center></th>
				<th><center><b>Quantity</b></center></th>
			</tr>
			<!-- Table rows for product1 -->
			<tr>
				<td style ="width:4%;"><input type="checkbox" name="item1" value="1" onchange="toggleQuantity('quantity1', this)"></td>
				<td class = "image"><img src="pic1.png"></td>
				<td class = "product"><b>HP Pavilion x360 14 inch 2-in-1 Laptop 14-ek1039TU Silver</b></td>
				<td class = "price"><b>RM 3,999.00</b></td>
				<td><input type="number" name="quantity1" value="0" min="0" max="10" required ></td>
			</tr>
			<!-- Table rows for product2 -->
			<tr>
				<td><input type="checkbox" name="item2" value="1" onchange="toggleQuantity('quantity2', this)"></td>
				<td class = "image"><img src="pic2.jpg"></td>
				<td class = "product"><b> HP 24 inch All-in-One Desktop PC</b></td>
				<td class = "price"><b>RM 2,599.00</b></td>
				<td><input type="number" name="quantity2" value="0" min="0" max="10" required ></td>
			</tr>
			<!-- Table rows for product3 -->
			<tr>
				<td><input type="checkbox" name="item3" value="1" onchange="toggleQuantity('quantity3', this)"></td>
				<td class = "image"><img src="pic3.png"></td>
				<td class = "product"><b> Western Digital My Passport 1TB USB 3.0 External Hard Drives New Design</b></td>
				<td class = "price"><b>RM 239.00</b></td>
				<td><input type="number" name="quantity3" value="0" min="0" max="10" required ></td>
			</tr>
			<!-- Table rows for product4 -->
			<tr>
				<td><input type="checkbox" name="item4" value="1" onchange="toggleQuantity('quantity4', this)"></td>
				<td class = "image"><img src="pic4.png"></td>
				<td class = "product"><b> 2.4GHz Mini Wireless Optical Game Mouse / USB Receiver</b></td>
				<td class = "price"><b>RM 25.99</b></td>
				<td><input type="number" name="quantity4" value="0" min="0" max="10" required ></td>
			</tr>
			<!-- Table rows for product5 -->
			<tr>
				<td><input type="checkbox" name="item5" value="1" onchange="toggleQuantity('quantity5', this)"></td>
				<td class = "image"><img src="pic5.png"></td>
				<td class = "product"><b> Anti Thief Backpack Business Fits for 15.6 inch Laptop USB Charging Water Repellent</b></td>
				<td class = "price"><b>RM 124.00</b></td>
				<td><input type="number" name="quantity5" value="0" min="0" max="10" required ></td>
			</tr>
			<!-- Table rows for product6 -->
			<tr>
				<td><input type="checkbox" name="item6" value="1" onchange="toggleQuantity('quantity6', this)"></td>
				<td class = "image"><img src="pic6.png"></td>
				<td class = "product"><b> Razer BlackShark V2 Multi-Platform Wired E-Sports Headset</b></td>
				<td class = "price"><b>RM 339.00</b></td>
				<td> <input type="number" name="quantity6" value="0" min="0" max="10" required ></td>
			</tr>
		</table>
		<br> <!-- For space -->
		
		<!-- Payment Method Section -->
		<div class = "payment">
			<p id ="method"><span class="requirement">*</span>Payment Method:</p>
			<p>
				<input type="radio" name="payment" value="Cash" required> Cash <br>
				<input type="radio" name="payment" value="Visa/MasterCard"> Visa / Master Card <br>
				<input type="radio" name="payment" value="OnlineTransfer"> Online Transfer
			</p>
			<p id ="sst">&nbsp;6% SST Sales Tax rate will be charged on computer products</p>
		</div>
		<br>
		<center>
			<!-- Submit and Clear Buttons -->	
			<div class = "button">
				<button type="submit" class ="btn" name="submit">Submit</button>
				<button type="reset" class ="btn" name="clear">Clear</button>
			</div>
		</center>
	</form>

	<!-- JavaScript function for toggling quantity input fields -->
	<script>
	function toggleQuantity(quantityId, checkbox) {
		var quantityInput = document.getElementsByName(quantityId)[0];
		var includeHiddenInput = document.getElementsByName('include' + quantityId)[0];
		if (!checkbox.checked) {
			quantityInput.value = 0;
			includeHiddenInput.value = 0;
		} else {
			quantityInput.value = 1;
			includeHiddenInput.value = 1;
		}
		quantityInput.disabled = !checkbox.checked;
		if (checkbox.checked) {
			quantityInput.removeAttribute('required');
		} else {
			quantityInput.setAttribute('required', 'required');
		}
	}
	</script>
</body>
</html>