<html>
<head>
	<title>PSP PC-Shop</title>
	<style>
	
		/* CSS styles for header */
		h1 {
		  background-color: purple;
		  width: 100%; 
		  height: 45px;
		  color: white;
		  text-align: center;
		  margin: 0 ; 
		  padding: 20px 0 20px 0;
		}

		/* CSS styles for buttons */
		input[type="button"] {
		  width: 10%; 
		  margin-top: 5px;
		  background-color: purple;
		  color: white;
		  padding: 10px 0 10px 0;
		}
		
		input[type="button"]:hover {
		  background-color: #2A38F5;
		  color: purple;
		}

		/* CSS styles for tables */
		table {
		font-family: arial, sans-serif;
		border-collapse: collapse;
		width: 100%; 
		margin-top: 0;
		}

		
		td, th {
		border: 1px solid #dddddd;
		text-align: left;
		padding: 8px;
		}
		
		/* CSS styles for empty space */
		#empty{
			height: 40px;
		}

		/* CSS styles for alternating row colors */
		.color tr:nth-child(odd) {
		background-color: #E8E8E8;
		}	
		
		/* CSS styles for alternating row colors */
		.color1 tr:nth-child(even) {
		background-color: #E8E8E8;
		}	
		
		/* CSS styles for alternating row colors */
		.color2 tr:nth-child(odd) {
		background-color: #E8E8E8;
		}	
		
		/* CSS styles for required fields */
		.requirement {
		color: red;
		font-weight: bold;
		margin-right: 5px; 
		}
		
		/* CSS styles for input elements */
		.row{
			width: 38%;
		}
			
		.main{
			width: 30%;
		}
		
		#text{
			height:70px;
			width: 30%;
		}
		
		#product{
			background-color: purple; 
			color: white;
		}
		
		.product{
			font-weight: bold;
			width: 38%;
		}
		
		.price{
			font-weight: bold;
			text-align: center;
			width: 18%;
		}
		
		.quantity{
			font-weight: bold;
			text-align: center;
			width: 20%;
		}
		
		.total{
			text-align: center;
			font-weight: bold;
		}
		
		.payment{
			width: 76%;
			font-weight: bold;
		}
		
		.amount{
			font-weight: bold;
			text-align: center;
		}
		
		.final{
			width: 76%;
			height: 50px; 
			font-weight: bold;
			text-align: right;
		}
		
		.amount1{
			background-color: purple;
			color: white;
			font-weight: bold;
			text-align: center;
		}
		
	</style>
</head>
<body>
	<!-- Header -->
	<h1>Welcome to PSP PC-Shop</h1>
	<!-- PHP code for processing form data and calculations -->
	<?php
		// Retrieve form data from product.php
		$name = $_POST["name"] ?? 0;
		$email = $_POST["email"] ?? 0;
		$phone = $_POST["phone"] ?? 0;
		$address = $_POST["address"] ?? 0;
		$date = $_POST["date"] ?? 0;
		$timestamp = strtotime($date);
		$formattedDate = date('d-m-Y', $timestamp);
		
		// Retrieve item quantities and calculate sales fromm product.php
		$item1 = $_POST["item1"] ?? 0;
		$item2 = $_POST["item2"] ?? 0;
		$item3 = $_POST["item3"] ?? 0;
		$item4 = $_POST["item4"] ?? 0;
		$item5 = $_POST["item5"] ?? 0;
		$item6 = $_POST["item6"] ?? 0;
		
		$quantity1 = $_POST["quantity1"] ?? 0;
		$quantity2 = $_POST["quantity2"] ?? 0;
		$quantity3 = $_POST["quantity3"] ?? 0;
		$quantity4 = $_POST["quantity4"] ?? 0;
		$quantity5 = $_POST["quantity5"] ?? 0;
		$quantity6 = $_POST["quantity6"] ?? 0;
		$payment = $_POST["payment"] ?? 0;
		
		$sales1 = $quantity1 * 3999;
		$sales2 = $quantity2 * 2599;
		$sales3 = $quantity3 * 239;
		$sales4 = $quantity4 * 25.99;
		$sales5 = $quantity5 * 124;
		$sales6 = $quantity6 * 339;
	
		// Calculate total sales
		$totalsales = $sales1 + $sales2 + $sales3 + $sales4 + $sales5 + $sales6;
		
		// Apply discount if total sales exceed 2000
		if ($totalsales > 2000){
			$discount = $totalsales * 0.05;
		}else{
			$discount = 0;
		}
		
		// Calculate tax and final amount
		$tax = $totalsales * 0.06;
		$amount = ($totalsales - $discount) + $tax;
	
	?>
	<!-- Form -->
    <form action="product.php">
		<!-- Customer Information Table -->
		<table class = "color" align="center" border="2">
			<!-- Name info -->
			<tr>
				<td class = "row"><b><span class="requirement">*</span>Full Name:</b></td>
				<td><input type="text" name="name" class ="main" value = "<?php echo $name; ?>" disabled></td>
			</tr>
			<!-- Email info -->
			<tr>
				<td><span class="requirement">*</span><b>Email:</b></td>
				<td><input type="email" class ="main" name="email" value = "<?php echo $email; ?>" disabled></td>
			</tr>
			<!-- Phone Number info -->
			<tr>
				<td><span class="requirement">*</span><b>Phone Number:</b></td>
				<td><input type="text" class ="main" name="phone" value = "<?php echo $phone ?>" disabled></td>
			</tr>
			<!-- Address info -->
			<tr>
				<td><span class="requirement">*</span><b>Address:</b></td>
				<td><textarea id = "text" name="address" disabled><?php echo $address; ?></textarea></td>
			</tr>
			<!-- Date info -->
			<tr>
				<td><span class="requirement">*</span><b>Date:</b></td>
				<td><input type="text" class ="main" name="date" value ="<?php echo $formattedDate; ?>" disabled></td>
			</tr>
			<!-- For empty row -->
			<tr>
				<td colspan = 2 id="empty"></td>
			</tr>
		</table>
		
		<!-- Product Details Table -->
		<table class="color1" align="center" border="2">
		<!-- Table headers -->
		<h1>Product Details</h1>
			<tr id = "product">
				<th><center><b>Item Name</b></center></th>
				<th><center><b>Unit Price</b></center></th>
				<th><center><b>Quantity</b></center></th>
				<th><center><b>Total</b></center></th>
			</tr>
			<!-- Table rows for product1 -->
			<tr>
				<td class = "product">HP Pavilion x360 14 inch 2-in-1 Laptop 14-ek1039TU Silver</td>
				<td class = "price">RM 3,999.00</td>
				<td class = "quantity"><?php echo $quantity1; ?></td>
				<td class = "total">RM <?php echo number_format($sales1,2); ?></td>
			</tr>
			<!-- Table rows for product2 -->
			<tr>
				<td class = "product">HP 24 inch All-in-One Desktop PC</td>
				<td class = "price">RM 2,599.00</td>
				<td class = "quantity"><?php echo $quantity2; ?></td>
				<td class = "total">RM <?php echo number_format($sales2,2); ?></td>
			</tr>
			<!-- Table rows for product3 -->
			<tr>
				<td class = "product">Western Digital My Passport 1TB USB 3.0 External Hard Drives New Design</td>
				<td class = "price">RM 239.00</td>
				<td class = "quantity"><?php echo $quantity3; ?></td>
				<td class = "total">RM <?php echo number_format($sales3,2); ?></td>
			</tr>
			<!-- Table rows for product4 -->
			<tr>
				<td class = "product">2.4GHz Mini Wireless Optical Game Mouse / USB Receiver</td>
				<td class = "price">RM 25.99</td>
				<td class = "quantity"><?php echo $quantity4; ?></td>
				<td class = "total">RM <?php echo number_format($sales4,2); ?></td>
			</tr>
			<!-- Table rows for product5 -->
			<tr>
				<td class = "product">Anti Thief Backpack Business Fits for 15.6 inch Laptop USB Charging Water Repellent</td>
				<td class = "price">RM 124.00</td>
				<td class = "quantity"><?php echo $quantity5; ?></td>
				<td class = "total">RM <?php echo number_format($sales5,2); ?></td>
			</tr>
			<!-- Table rows for product6 -->
			<tr>
				<td class = "product">Razer BlackShark V2 Multi-Platform Wired E-Sports Headset</td>
				<td class = "price">RM 339.00</td>
				<td class = "quantity"><?php echo $quantity6; ?></td>
				<td class = "total">RM <?php echo number_format($sales6,2); ?></td>
			</tr>
			<!-- For empty row -->
			<tr>
				<td colspan = 4 id="empty"></td>
			</tr>
		</table>
		
		<!-- Bill Summary Table -->
		<table class="color2" align="center" border="2">
		<!-- Table headers -->
		<h1>Bill</h1>
			<!-- Table row for Payment method -->
			<tr>
				<td class = "payment">Payment Method</td>
				<td class = "amount"><?php echo $payment; ?></td>
			</tr>
			<!-- Table row for Total Sales -->
			<tr>
				<td class = "payment">Total Sales</td>
				<td class = "amount">RM <?php echo number_format($totalsales, 2); ?></td>
			</tr>
			<!-- Table row for 5% Discount -->
			<tr>
				<td class = "payment">Discount (5% if total sales above RM 2000)</td>
				<td class = "amount">RM <?php echo number_format($discount,2); ?></td>
			</tr>
			<!-- Table row for 6% SST charged -->
			<tr>
				<td class = "payment">6% SST charged</td>
				<td class = "amount">RM <?php echo number_format($tax,2); ?></td>
			</tr>
			<!-- Table row for Total Price -->
			<tr>
				<td class = "final"><b>TOTAL</b></td>
				<td class = "amount1">RM <?php echo number_format($amount,2); ?></td>
			</tr>
		</table>
		<!-- Back Button -->
		<input type="button" onclick="history.back()" value="Back">
	</form>
</body>
</html>