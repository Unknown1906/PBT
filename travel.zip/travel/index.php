<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Travel Reservation Form</title>
	<style>
		table {
			border-style: outset;
			border-width: 7px;
			border-color: firebrick;
		}
	</style>

</head>

<body style="font-family:Segoe, 'Segoe UI', 'DejaVu Sans', 'Trebuchet MS', Verdana, 'sans-serif'">
	<form action="process.php" method="Post">
	  <h1 align="center">Travel Reservation Form</h1>
	  <p align="center"><em>* mandatory field</em></p>
		<table width="30%" align="center">
	      <tr>
	        <td width="33%">Full name <font color='red'> *</font></td>
	        <td width="3%">:</td>
	        <td width="64%"><input type="text" name="fullname" pattern="[a-zA-Z -]+" required></td>
          </tr>
	      <tr>
	        <td>Phone number <font color='red'> *</font></td>
	        <td>:</td>
	        <td><input type="text" name="phone" pattern="[0-9]{3}-[0-9]{7}" required>
            Example: 012-3456789</td>
          </tr>
	      <tr>
	        <td>Email address <font color='red'> *</font></td>
	        <td>:</td>
	        <td><input type="email" name="email" required></td>
          </tr>
	      <tr>
	        <td>Destination <font color='red'> *</font></td>
	        <td>:</td>
	        <td><select name="destination" required>
	                      <option>Please Select</option>
				<option>Langkawi</option>
				<option>Penang</option>
				<option>Kuala Lumpur</option>
				<option>Johor Bahru</option>
				<option>Kuala Terengganu</option></option>
				<option>Kota Kinabalu</option>
				<option>Kuching</option>
            </select></td>
          </tr>
	      <tr>
	        <td>Departure date <font color='red'> *</font></td>
	        <td>:</td>
	        <td><input type="date" name="depart" required></td>
          </tr>
	      <tr>
	        <td>Departure time <font color='red'> *</font></td>
	        <td>:</td>
	        <td><input type="time" name="time"></td>
          </tr>
	      <tr>
	        <td>Number of persons <font color='red'> *</font></td>
	        <td>:</td>
	        <td><input type="number" name="person" required></td>
          </tr>
	      <tr>
	        <td>Which service would you like to avail? <font color='red'> *</font></td>
	        <td>:</td>
	        <td><input type="checkbox" name="avail[]" value="Boarding" required>Boarding<br>
			  <input type="checkbox" name="avail[]" value="Fooding">Fooding<br>
			  <input type="checkbox" name="avail[]" value="Sight Seeing">Sight Seeing</td>
          </tr>
	      <tr>
	        <td>Discount coupon code</td>
	        <td>:</td>
	        <td><input type="text" name="discount">(20% discount with coupon)</td>
          </tr>
	      <tr>
	        <td colspan="3">&nbsp;</td>
          </tr>
	      <tr>
	        <td colspan="3"><input type="checkbox" name="tnc" required>
            I accept the Terms and Conditions</td>
          </tr>
	      <tr>
		 <td colspan='3'><input type="submit" value='Complete Reservation'> <input type="reset"></td>
          </tr>
      </table>
    </form>
</body>
</html>