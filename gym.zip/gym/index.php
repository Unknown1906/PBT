<html>
<head>
	<title>Student Information</title>
	<style>
		table {
			border-style: outset;
			border-width: 7px;
			border-color: blueviolet;
		}
	</style>
</head>
<form method="post" action="process.php">
 <h2 align="center">:: GYM MEMBERSHIP FORM::</h2>
  <table align="center">
    <tr>
      <td>Full Name<font color='red'> *</font></td>
      <td>:</td>					
		<td><input name="FName" type="text" size="30" required></td>
    </tr>
    <tr>
      <td>IC Number<font color='red'> *</font></td>
      <td>:</td>
      <td><input name="icNo" type="text" size="12" required> Example: 990218085599</td>				 
    </tr>
    <tr>
      <td>Gender<font color='red'> *</font></td>
      <td>:</td>
		<td><input name="gender" type="radio" value="Male" required>Male 
        <input name="gender" type="radio" value="Female" required>Female</td>
    </tr>
    <tr>
      <td>Address<font color='red'> *</font></td>
      <td>:</td>
      <td><textarea name="address" cols="50" rows="3" required></textarea></td>
    </tr>
    <tr>
      <td>Phone Number<font color='red'> *</font></td>
      <td>:</td>
      <td><input name="phoneNo" type="text" size="12" required></td>
    </tr>
    <tr>
      <td>Gym Session<font color='red'> *</font></td>
      <td>:</td>
      <td> 
        <select name="session" required>
		  <option value="">Please select</option>
          <option value="group1">Group1: 2pm - 4pm</option>					
          <option value="group2">Group2: 4pm - 6pm</option>	
		  <option value="group3">Group3: 8pm - 10pm</option>
        </select>
    </td>
    </tr>
    
    <tr>
      <td>Email<font color='red'> *</font></td>	
      <td>:</td>
      <td><input name="email" type="email" size="30" required></td>
    </tr>
    <tr>
      <td>Height (in meter)<font color='red'> *</font></td>
      <td>:</td>							
      <td><input name="height" type="text" size="3" required></td>
    </tr>
	<tr>
	  <td>Weight (in kilogram) <font color='red'>*</font></td>
      <td>:</td>							
      <td><input name="weight" type="text" size="3" required></td>
    </tr>
	<tr>
      <td colspan="3"><input type="submit" name="Submit" value="Submit">
      <input name="Reset" type="submit" id="Reset" value="Reset"></td>
    </tr>
  </table>
</form>

</body>
</html> 