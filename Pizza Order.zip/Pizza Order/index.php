<html>
<head>
<title>Ordering Form</title>
<style type="text/css">

.style7 {
	font-family: Geneva, Helvetica, sans-serif; 
}

body {
	background-color:#ffffff;
}

table{
	border: 2px solid black;
  	border-collapse: collapse;
  	width: 50%;
}

th, td {
  	text-align: left;
  	padding: 2px;
}


.error {
	color: #ffffff;
}

border-color: orange;  
  border-width: 5px;  
  border-style: inset;  
-->
</style>
<style>
  .required:after {
    content:" *";
    color: red;
  }
</style>

</head>
<body>


<form name="form1" method="post" action="process.php">
 <h2 align="center" class="style7">:: PIZZA TAKE OUT ORDER FORM ::</h2>
  
  
   <table align="center" >
	<tr>
		<td> <span class="style7"><h3>MENU </h3></span></td>
	</tr>
	<tr><td> </td></tr>

	<tr>
		<td><input type="checkbox" name="super" value="Supreme" > <span class="style7">PIZZA SUPREME (RM14)</span>
		&nbsp
		&nbsp
		&nbsp
		 <span class="style7">Quantity:</span> 				
			<span class="style7">
				<select name="qsuper">
				<option value="1" selected>1</option>					
				<option value="2">2</option>						
				<option value="3">3</option>
			</select></span>
		</td>


			
	 </tr>
	<tr><td><br> </td></tr>
	
	<tr>
		<td><input type="checkbox" name="pepper" value="Pepperoni" > <span class="style7">PIZZA PEPPERONI (RM15)</span> 
	&nbsp
		&nbsp
		&nbsp
		 <span class="style7">Quantity:</span> 				
			<span class="style7">
				<select name="qpepper">
				<option value="1" selected>1</option>					
				<option value="2">2</option>						
				<option value="3">3</option>
			</select></span>
		</td>

			
	 </tr>
	<tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
	  </tr>
   </table>
  <br>
  <!----CUSTOMER DETAILS----->
	<table align="center">
	<tr>
		<td> <span class="style7"><h3>CUSTOMER DETAILS </h3></span></td>
		<td> <span class="style7"> </span></td>
	</tr>

    <tr>
      <td><span class="style7">Name <span class="required"></span></span></td>
      <td><span class="style7">:</span></td>					
      <td><input name="name" type="text" size="30"><span class="error"><?php echo $nameErr;?></span></td>
    </tr>
    <tr>
      <td><span class="style7" required>Phone Number<span class="required"></span> </span></td>
      <td><span class="style7">:</span></td>
      <td><input name="phone" type="text" ><span class="error"><?php echo $phoneErr;?></span></td>				 
    </tr>
    <tr>
      <td><span class="style7" required>Email<span class="required"></span></span></span></td>	
      <td><span class="style7">:</span></td>
      <td><input name="email" type="text" size="30"><span class="error"><?php echo $emailErr;?></span></td>
    </tr>
    <tr>
      <td><span class="style7" required>Address<span class="required"></span></span></td>
      <td><span class="style7">:</span></td>
      <td><span class="style7">								 
        <textarea name="address" cols="50" rows="3"></textarea> </span><span class="error"><?php echo $addressErr;?></span></td>
    </tr>
	<tr><td><br> </td></tr>
	<tr>
      <td><span class="style7" >Select your preferred method for this order<span class="required"></span></span></td>
      <td><span class="style7">:</span></td>
    </tr>
	<tr>  
	  <td><span class="style7">
        <input name="methods" type="radio" value="Delivery" > Delivery (Additional RM10)
		</span><span class="error"><?php echo $deliveryErr;?></span></td></td>
    </tr>
	<tr><td><span class="style7">
	<input name="methods" type="radio" value="CarryOut">
		Carry Out (Discount 2%)</span><span class="error"><?php echo $carryErr;?></span></td>
    </tr>  

    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td><input type="submit" name="Submit" value="Submit"> 
      <input name="Reset" type="submit" id="Reset" value="Reset"></td>
     </tr>
	 <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
	  </tr>
  </table>

  <p>&nbsp;</p>
  <p>&nbsp;</p>
  
  

</form>

</body>
</html> 
