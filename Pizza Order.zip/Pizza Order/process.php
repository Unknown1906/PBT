<html>
<head>
<title>Recorded Information</title>
<style type="text/css">
.style7 {
	font-family: Geneva, Arial, Helvetica, sans-serif; font-weight: bold; 
}

body {
	background-color:#ffffff;
}

table{
	border: 2px solid black;
  	border-collapse: collapse;
  	width: 50%;
}

th, td {
  	text-align: left;
  	padding: 1px;
}

tr:nth-child(even) {
	background-color: #ffffff;
}

.error {
	color: #FF0000;
}
-->
</style>
</head>
<body>

<?php	
$name = $_POST['name']; 	
$phone = $_POST["phone"];
$email = $_POST["email"];         
$address = $_POST["address"]; 
$qpepper = $_POST["qpepper"];
$qsuper = $_POST["qsuper"];	 


if(isset($_POST['pepper'])){	
	$pepper = $_POST["pepper"];
}
else{
	$pepper='Pizza Not Selected';
}
if(isset($_POST['super'])){	
	$super = $_POST["super"];
}
else{
	$super='Pizza Not Selected';
}

if(isset($_POST['methods'])){	
	$methods= $_POST["methods"];
}
else{
	$methods='*methods Not Selected';
}
if(isset($_POST['discount'])){	
	$discount = $_POST["discount"];
}
else{
	$discount='Pizza Not Selected';
}

$name2=strtoupper($name);
?> 		

<h2 align="center" class="style7">:: RECORDED INFORMATION :: </h2> 
  <table align="center">
    <tr>
      <td height="30" colspan="3"><?php echo "<i>"."<b>"."<font style='font-family:arial;' size='4' color='Blue'>"."Hello, ".$name2."</font>"."</b>"."</i>"; ?></td>
    </tr>
	
    <tr>
      <td height="30"><span class="style7">Phone Number</span></td>
      <td><span class="style7">:</span></td>						
      <td><span class="style7"><?php echo $phone; ?></span></td>
    </tr>
    <tr>
      <td height="30"><span class="style7">Email</span></td>
      <td><span class="style7">:</span></td>	
      <td><span class="style7"><?php echo $email; ?></span></td>
    </tr>
    <tr>
      <td height="48"><span class="style7">Address</span></td>
      <td><span class="style7">:</span></td>
      <td><span class="style7"><?php echo  strtoupper($address); ?></span></td>
    </tr>
    <tr>
      <td><span class="style7">Your preferred method is </span></td>
	  <td><span class="style7">:</span></td>
	  <td><span class="style7"><?php echo strtoupper($methods); ?></span></td>
    
    </tr>
    <tr><td><br> </td></tr>   
	<!-------ORDER INFO----->
	<tr>
      <td width="191" height="38" colspan="3"><span class="style7"><font style='font-family:arial;' size='4' color='Blue'>Here is Your Order</font></span></td>			
    </tr>
	   <?php 
		if(isset($_POST['pepper']) && isset($_POST['super'])) {		
		
			
			if(isset($_POST['methods']) AND $_POST['methods']=='Delivery')
			{
				//list of order
				echo "<tr>";
				echo"<td width='250' height='38'><span class='style7'>Your Order is</span></td>";
				echo "<td width='32'><span class='style7'>:</span></td>";
				echo " <td><span class='style7'>";
				echo $qpepper, ' PIZZA ', strtoupper($pepper);
				echo "</br>";  
				echo $qsuper, ' PIZZA ', strtoupper($super);
				$total1 = (($qsuper * 14)+($qpepper * 15)+10);  
				echo "</br>";  
				echo "</span></td>";
				echo "</tr>";
				//total order
				echo "<tr>";
				echo"<td width='250' height='38'><span class='style7'>Your Total Order is </span></td>";
				echo "<td width='32'><span class='style7'>:</span></td>";
				echo "<td width='32'><span class='style7'>RM ".$total1."</span></td>";
				echo "</tr>";
				
			}
			else if(isset($_POST['methods']) AND $_POST['methods']=='CarryOut')
			{
				//list of order
				echo "<tr>";
				echo"<td width='250' height='38'><span class='style7'>Your Order is</span></td>";
				echo "<td width='32'><span class='style7'>:</span></td>";
				echo " <td><span class='style7'>";
				echo $qpepper, ' PIZZA ', strtoupper($pepper);
				echo "</br>";  
				echo $qsuper, ' PIZZAa ', strtoupper($super);
				$total2 = ((($qsuper * 14)+($qpepper * 15))*0.98);  
				echo "</br>";  
				echo "</br>";  
				echo "</span></td>";
				echo "</tr>";
				//total order
				echo "<tr>";
				echo"<td width='250' height='38'><span class='style7'>Your Total Order is </span></td>";
				echo "<td width='32'><span class='style7'>:</span></td>";
				echo "<td width='32'><span class='style7'>RM ".$total2."</span></td>";
				echo "</tr>";
			}	
		} else if(isset($_POST['pepper'])) {
			
			if(isset($_POST['methods']) AND $_POST['methods']=='Delivery')
			{
				//list of order
				echo "<tr>";
				echo"<td width='250' height='38'><span class='style7'>Your Order is</span></td>";
				echo "<td width='32'><span class='style7'>:</span></td>";
				echo " <td><span class='style7'>";
				echo $qpepper, ' PIZZA ', strtoupper($pepper);
				echo "</br>"; 
				$total3 = ($qpepper * 15)+10;  
				echo "</br>";
				echo "</br>";  
				echo "</span></td>";
				echo "</tr>";
				//total order
				echo "<tr>";
				echo"<td width='250' height='38'><span class='style7'>Your Total Order is </span></td>";
				echo "<td width='32'><span class='style7'>:</span></td>";
				echo "<td width='32'><span class='style7'>RM ".$total3."</span></td>";
				echo "</tr>";				
			}
			else if(isset($_POST['methods']) AND $_POST['methods']=='CarryOut')
			{
				//list of order
				echo "<tr>";
				echo"<td width='250' height='38'><span class='style7'>Your Order is</span></td>";
				echo "<td width='32'><span class='style7'>:</span></td>";
				echo " <td><span class='style7'>";
				echo $qpepper, ' PIZZA ', strtoupper($pepper);
				echo "</br>"; 
				$total4 = ($qpepper * 15)*0.98;  
				echo "</br>";  
				echo "</br>";  
				echo "</span></td>";
				echo "</tr>";
				//total order
				echo "<tr>";
				echo"<td width='250' height='38'><span class='style7'>Your Total Order is </span></td>";
				echo "<td width='32'><span class='style7'>:</span></td>";
				echo "<td width='32'><span class='style7'>RM ".$total4."</span></td>";
				echo "</tr>";			
			}
		} else if(isset($_POST['super'])) {
			if(isset($_POST['methods']) AND $_POST['methods']=='Delivery')
			{
				//list of order
				echo "<tr>";
				echo"<td width='250' height='38'><span class='style7'>Your Order is</span></td>";
				echo "<td width='32'><span class='style7'>:</span></td>";
				echo " <td><span class='style7'>";
				echo $qsuper, ' PIZZA ', strtoupper($super);
				echo "</br>"; 
				$total5 = ($qsuper * 14)+10;  
				echo "</br>";  
				echo "</br>";  
				echo "</span></td>";
				echo "</tr>";
				//total order
				echo "<tr>";
				echo"<td width='250' height='38'><span class='style7'>Your Total Order is </span></td>";
				echo "<td width='32'><span class='style7'>:</span></td>";
				echo "<td width='32'><span class='style7'>RM ".$total5."</span></td>";
				echo "</tr>";			
			}
			else if(isset($_POST['methods']) AND $_POST['methods']=='CarryOut')
			{
				//list of order
				echo "<tr>";
				echo"<td width='250' height='38'><span class='style7'>Your Order is</span></td>";
				echo "<td width='32'><span class='style7'>:</span></td>";
				echo " <td><span class='style7'>";
				echo $qsuper, ' PIZZA ', strtoupper($super);
				echo "</br>"; 
				$total6 = ($qsuper * 14)*0.98;  
				echo "</br>";  
				echo "</br>";  
				echo "</span></td>";
				echo "</tr>";
				//total order
				echo "<tr>";
				echo"<td width='250' height='38'><span class='style7'>Your Total Order is </span></td>";
				echo "<td width='32'><span class='style7'>:</span></td>";
				echo "<td width='32'><span class='style7'>RM ".$total6."</span></td>";
				echo "</tr>";			
			}
		} else {
			echo 'you did not select any menu';
		echo $pepper, ' Pizza ', $super;
		}		
?>
  </table>
  </body>
  </html>
  
