<html>
<head>
	<title>Student Information</title>
	<style>
		table {
			border-style: outset;
			border-width: 7px;
			border-color: blueviolet;
		}
	</style>
</head>
<h2 align="center">:: STUDENT INFORMATION ::</h2>
<form method="post" action="process.php">
  <table align="center">
    <tr>
      <td>Full Name<font color='red'> *</font></td>
      <td>:</td>					
      <td><input name="FName" type="text" size="30" required></td>
    </tr>
    <tr>
      <td>Matric Number<font color='red'> *</font></td>
      <td>:</td>
      <td><input name="matricNo" type="text" required></td>	 
    </tr>
    <tr>
      <td>Gender<font color='red'> *</font></td>
      <td>:</td>
      <td><input name="gender" type="radio" value="Male" required>Male 
<input name="gender" type="radio" value="Female" required>Female</td>
    </tr>
    <tr>
      <td>Address<font color='red'> *</font></td>
      <td>:</td>
<td><textarea name="address" cols="50" rows="3" required></textarea></td>
    </tr>
    <tr>
      <td>Class<font color='red'> *</font></td>
      <td>:</td>
      <td> 
        <select name="class" required>
	<option value="">Please select</option>
              <option value="DIP4A">DIP5A</option>				<option value="DIP4B">DIP5B</option>			
        </select>
    </td>
    </tr>
    <tr>
      <td>Email<font color='red'> *</font></td>	
      <td>:</td>
      <td><input name="email" type="text" size="30" required></td>
    </tr>
    <tr>
      <td colspan="3">&nbsp;</td>
    </tr>
	<tr>
	<th colspan="3">Marks for DFP50193 Web Programming</th>
	</tr>
	<tr>
      <td colspan="3">&nbsp;</td>
    </tr>  
    <tr>
      <td>Case Study Marks<font color='red'> *</font></td>
      <td>:</td>							
      <td><input name="csmark" type="text" size="2" required></td>
    </tr>
      <tr>
      <td>Problem Base Task Marks <font color='red'>*</font></td>
      <td>:</td>							
      <td><input name="pbtmark" type="text" size="2" required></td>
    </tr>
	<tr>
	  <td>Lab Task Marks<font color='red'> *</font></td>
      <td>:</td>							
	  <td><input name="labmark" type="text" size="2" required></td>
    </tr>
    <tr>
	  <td>Presentations Marks <font color='red'>*</font></td>
	  <td>:</td>
<td><input name="presentmark" type="text" size="2" required></td>
    </tr>
     <tr>
      <td>Practical Test Marks <font color='red'>*</font></td>
      <td>:</span></td>					
      <td><input name="practmark" type="text" size="2" required></td>
    </tr>
    <tr>
      <td colspan="3"><input type="submit" name="Submit" value="Submit">
      <input name="Reset" type="submit" id="Reset" value="Reset"></td>
    </tr>
  </table>
</form>
</body>
</html> 